"""


def firstVerse(count, bottleTense):
    firstVerse = "%s %s of beer on the wall, %s %s of beer." % (count, bottleTense, count, bottleTense)
    print(firstVerse)

def secondVerse(count, bottleTense):
    secondVerse = "Take one down and pass it around, %s %s of beer on the wall!\n" % (count, bottleTense)
    print(secondVerse)

def lyrics():
    count = 99
    bottleTense = "bottles"

    while count > 1:
        firstVerse(count, bottleTense)
        count -= 1

        if count > 1:
            secondVerse(count, bottleTense)
        elif count == 1:
            bottleTense = "bottle"
            secondVerse(count, bottleTense)

    firstVerse(count, bottleTense)

    count = "no more"
    bottleTense = "bottles"
    secondVerse(count, bottleTense)

    count = "No more"
    firstVerse(count, bottleTense)
    print("Go to the store and buy some more, 99 bottles of beer on the wall!\n")

lyrics()


"""




def Firstverse(count, bottle_tense):
    Firstverse = f"{count} {bottle_tense} of beer on the wall, {count} {bottle_tense} of beer."
    print(Firstverse)


def Secondverse(count, bottle_tense):
    Secondverse = f"Take one down and pass it around, {count} {bottle_tense} of beer on the wall!\n"
    print(Secondverse)


def Lyrics():
    count = 100
    bottle_tense = 'botlles'

    while count > 1:
        Firstverse(count, bottle_tense)
        count -= 1

        if count > 1: 
            Secondverse(count, bottle_tense)
        elif count == 1:
            bottle_tense = 'bottle'
            Secondverse(count, bottle_tense)
    
    Firstverse(count, bottle_tense)
    count = "no more"
    bottle_tense = 'bottles'

    Secondverse(count, bottle_tense)

    count = "no more"

    Firstverse(count , bottle_tense)
    print("No more bottle left on the wall, go to the store and buy some more!")
    
    
    print("bought all the bottles, again 100 botlles on the wall!")
    

            


 


Lyrics()



