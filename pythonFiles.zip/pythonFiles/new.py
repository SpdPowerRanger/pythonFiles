class Present:
    

    data = None
    
    def __init__(self,data):
        
        self.data = data


x = Present(1)


class Node:

    data = None

    next_node = None


    def __init__(self,data):

        self.data = data

N1 = Node()

