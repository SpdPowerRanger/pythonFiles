import random

correct_number = random.randint(1,101)
print(correct_number)
guess_list = [0]






while True:

    # we can copy the code from above to take an input
    guess = int(input("Guess the correct number to win :  "))
    
    if guess < 1 or guess > 100:
        print("Invalid.\nTry again!")
        continue
    elif guess == correct_number:
        print(f"You are Correct.\nYou guessed it in only {len(guess_list)} guesses.")
        break
        
    guess_list.append(guess)
    
    if guess_list[-2]:
        if abs(correct_number-guess) < abs(correct_number-guess_list[-2]):
            print("Close.")
        else:
            print("Prevous was better.")

    

    """

    else:
        input("Wrong! Try Again? [y/n]: ")
        if 'y' or 'Y':
            continue
        else:
            break
    """        