import random 

words = ["tiger","cat","fish","towel","sauce","pan"]

rand_word = random.choice(words)
#print(rand_word)
#print("")
empty_spaces = ["_" for char in rand_word]
final_empty_spaces = ""
total_tries = len(empty_spaces) 
while total_tries > 0:
#final_empty_spaces != rand_word: 
	final_empty_spaces = "".join(empty_spaces)
	i=0

	if final_empty_spaces == rand_word:
		for space in empty_spaces:
			print(space, end = "")

		print("")
		print("You won")
		break
	else:
		for space in empty_spaces:
			print(space, end = "")

		print("")

	user_input = str(input("Enter a letter : "))
	
	if total_tries == 0:
		break
	
	while i < len(empty_spaces):
		if user_input == rand_word[i]:
			empty_spaces[i] = rand_word[i] 
			break

		elif user_input not in rand_word:
			total_tries -= 1
			if total_tries > 0:
				print("Total tries left : ",total_tries)
			elif total_tries == 0:
				print("Total tries left : ",total_tries)
				print("")
				print("You Lost.")
			break
		else:
	 		i += 1
	 		continue

	