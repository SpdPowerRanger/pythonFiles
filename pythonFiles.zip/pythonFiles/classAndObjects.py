class Node:

	data = None  
	""" This is called a variable within a class."""

	next_node = None  
	""" Another variable within a class."""

	""" We decide the name of any variable that we creat or make within a class."""

	def __init__(self, data): 
	
		""" ___init___() is a construct method in a class or within a class."""

		"""A construct within a class defines the behaviour of the objects of that class.""" 
		self.data = data      
	""" A "method" is nothing but a function(), which is just within a class."""
	""" self is just an input variable that is used in functions and methods for the object name or object that we cab define later."""


	""" If a class is a template then the methods in it are its data from which the properties and behaviour of that class is defined"""	

	def __repr__(self):
		""" Ignore this for now."""
		return"<data : %s>" % self.data


""" This is an oject that we are creating.""" 
N1 = Node(10) 
""" This means that N1 is an object (which we have just made),which belongs to the class of Node, that we had made earlier."""

""" We can make or define many objects."""
N2 = Node(0)
""" Here's another object N2 that we have created. Which belongs to the Node class."""


"""  These are the techniques by which we can print the variable data within a specific class."""

print(Node.data) 
""" print the data of a variable within a class by directly using the class in front of .variableNameWithinAClass"""
print(N2.data)
""" print the data of a variable within a class by using an object that you have created."""
print(N2) 

"""

Everything is cotained within a class. We only have to put all the work in a class to use objects.

Object is just a variable outside of a class which belongs to that class.

To assign a variable to a class and make it an object we just have to do : objName = className()
"""



class cats:
	name = "tom"
	next_cat = "billy"

	def __init__(self, name):
		
		color = None
		next_cat = "billy"



class dogs:

	names = "cat"



	def new_name(self,name):

		new_dog = cats(name)
		
		new_dog.next_cat = self.names

		print(new_dog.next_cat)




d1 = dogs()

d1.new_name("robert")






