# Importing The Random Module
import random

# Creating a list to hold words.
word_list = ["water","bottle","mango","apple"]

# Selecting a random word from the word list.
rand_word = random.choice(word_list)

# Printing the randomly selected word to check.
print(rand_word)

""" # Printing the words in word_list : 
for word in word_list:
	print(word, end = " ")
print("")
"""
emptyspace = '_'

# Creating a list (using list comprehension) of " _ ", whose count are equivalent to the number of characters in rand_word.  
empty_spaces = [emptyspace for char in rand_word]
# Printing empty_spaces to check.
# print(empty_spaces)
empty_spaces2 = [emptyspace for char in rand_word]

# A variable to check the total tries.
total_tries = len(rand_word)

# Printing the total tries which are left.
print("Total tries left :  ", total_tries)
print("")



i = 0
loop_count = 0

# Hangman game mechanics:


	# A while loop to run the input var till the word is guessed. 
while empty_spaces != rand_word or total_tries > 0:
	# A loop count to check how many times the loop has ran.
	loop_count+=1
	

	# printing the empty spaces which are to be filled.
	for space in empty_spaces:
		print(space, end = ' ')
	print("")	

	# Taking a string input.		
	char = str(input("Guess an alphabet form the word : "))
	print("")



	# While loop to check for the char in rand_word:
	while i < len(rand_word) or total_tries > 0:
		# If char is present in rand_word,
		if char == rand_word[i]:
			# Then, the input char will replace the "_" in the empty_spaces list in the same position or index 
			# as the input char is present in the index number of rand_word.  
			empty_spaces[i] = rand_word[i]
			continue			

	else:
		total_tries -= 1	
		print("Total tries left : ", total_tries)
	continue

"""
		for space in empty_spaces:
			print(space, end = " ")
		print("")
		
		elif char != rand_word[i]:
			total_tries -= 1
			print("Total tries left : ", total_tries)
			continue
		
	elif empty_spaces == rand_word:
		print(f"Congratulations!!!. You guessed the word in {loop_count} tries. ")
		break
"""	

"""	
	else:
		total_tries -= 1 
		print("Total tries left : ",total_tries)
		print("")
		for space in empty_spaces:
			print(space,end = " ")
			i+= 1

"""
